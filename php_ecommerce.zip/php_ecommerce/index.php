<?php
session_start();

if (isset($_SESSION['role'])) {
    if ($_SESSION['role'] == 'admin') {
        header('Location: admin/add_product.php');
        exit;
    } else {
        header('Location: user/products.php');
        exit;
    }
} else {
    header('Location: auth/login.php');
    exit;
}
?>