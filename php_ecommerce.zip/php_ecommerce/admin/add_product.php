<a href="../auth/logout.php">
    <button type="button">Logout</button>
</a>
<?php

session_start();
require '../config/db.php';

/*
Required Tables:

products
---------
id
name
price
description
created_at

product_images
---------
id
product_id
image
*/

$uploadPath = "../uploads/";

/*
====================================
ADD PRODUCT
====================================
*/
if (isset($_POST['add_product'])) {

    $name = trim($_POST['name']);
    $price = trim($_POST['price']);
    $description = trim($_POST['description']);

    $stmt = $conn->prepare("
        INSERT INTO products (name, price, description)
        VALUES (?, ?, ?)
    ");
    $stmt->execute([$name, $price, $description]);

    $productId = $conn->lastInsertId();

    // Multiple Image Upload
    if (!empty($_FILES['images']['name'][0])) {
        foreach ($_FILES['images']['tmp_name'] as $key => $tmpName) {

            $fileName = time() . "_" . $_FILES['images']['name'][$key];
            move_uploaded_file($tmpName, $uploadPath . $fileName);

            $imgStmt = $conn->prepare("
                INSERT INTO product_images (product_id, image)
                VALUES (?, ?)
            ");
            $imgStmt->execute([$productId, $fileName]);
        }
    }

    echo "Product Added Successfully";
}

/*
====================================
DELETE PRODUCT
====================================
*/
if (isset($_GET['delete'])) {

    $id = (int)$_GET['delete'];

    // Delete Images First
    $imgStmt = $conn->prepare("
        SELECT image FROM product_images
        WHERE product_id = ?
    ");
    $imgStmt->execute([$id]);
    $images = $imgStmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($images as $img) {
        if (file_exists($uploadPath . $img['image'])) {
            unlink($uploadPath . $img['image']);
        }
    }

    $conn->prepare("
        DELETE FROM product_images WHERE product_id = ?
    ")->execute([$id]);

    $conn->prepare("
        DELETE FROM products WHERE id = ?
    ")->execute([$id]);

    header("Location: add_product.php");
    exit;
}

/*
====================================
UPDATE PRODUCT
====================================
*/
if (isset($_POST['update_product'])) {

    $id = (int)$_POST['product_id'];
    $name = trim($_POST['name']);
    $price = trim($_POST['price']);
    $description = trim($_POST['description']);

    $stmt = $conn->prepare("
        UPDATE products
        SET name=?, price=?, description=?
        WHERE id=?
    ");
    $stmt->execute([$name, $price, $description, $id]);

    // New Multiple Image Upload
    if (!empty($_FILES['images']['name'][0])) {
        foreach ($_FILES['images']['tmp_name'] as $key => $tmpName) {

            $fileName = time() . "_" . $_FILES['images']['name'][$key];
            move_uploaded_file($tmpName, $uploadPath . $fileName);

            $imgStmt = $conn->prepare("
                INSERT INTO product_images (product_id, image)
                VALUES (?, ?)
            ");
            $imgStmt->execute([$id, $fileName]);
        }
    }

    echo "Product Updated Successfully";
}

/*
====================================
EDIT FETCH
====================================
*/
$editData = null;

if (isset($_GET['edit'])) {
    $editId = (int)$_GET['edit'];

    $stmt = $conn->prepare("
        SELECT * FROM products WHERE id = ?
    ");
    $stmt->execute([$editId]);
    $editData = $stmt->fetch(PDO::FETCH_ASSOC);
}

/*
====================================
VIEW PRODUCTS
====================================
*/
$stmt = $conn->query("
    SELECT * FROM products
    ORDER BY id DESC
");
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Product CRUD</title>
</head>
<body>

<h2>Product Management</h2>

<form method="POST" enctype="multipart/form-data">

    <input
        type="hidden"
        name="product_id"
        value="<?php echo $editData['id'] ?? ''; ?>"
    >

    <input
        type="text"
        name="name"
        placeholder="Product Name"
        required
        value="<?php echo $editData['name'] ?? ''; ?>"
    >
    <br><br>

    <input
        type="number"
        name="price"
        placeholder="Price"
        required
        value="<?php echo $editData['price'] ?? ''; ?>"
    >
    <br><br>

    <textarea
        name="description"
        placeholder="Description"
        required
    ><?php echo $editData['description'] ?? ''; ?></textarea>
    <br><br>

    <input
        type="file"
        name="images[]"
        multiple
    >
    <br><br>

    <?php if ($editData) { ?>
        <button type="submit" name="update_product">
            Update Product
        </button>
    <?php } else { ?>
        <button type="submit" name="add_product">
            Add Product
        </button>
    <?php } ?>

</form>

<hr>

<h2>Product List</h2>

<?php foreach ($products as $product) { ?>

    <div style="border:1px solid #ccc; padding:15px; margin:15px;">

        <h3><?php echo $product['name']; ?></h3>

        <p>Price: ₹<?php echo $product['price']; ?></p>

        <p><?php echo $product['description']; ?></p>

        <strong>Images:</strong><br>

        <?php
        $imgStmt = $conn->prepare("
            SELECT * FROM product_images
            WHERE product_id = ?
        ");
        $imgStmt->execute([$product['id']]);
        $images = $imgStmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($images as $img) {
            echo '<img src="../uploads/' . $img['image'] . '" width="100" style="margin:5px;">';
        }
        ?>

        <br><br>

        <a href="?edit=<?php echo $product['id']; ?>">
            Edit
        </a>

        |

        <a
            href="?delete=<?php echo $product['id']; ?>"
            onclick="return confirm('Delete this product?')"
        >
            Delete
        </a>

    </div>

<?php } ?>

</body>
</html>