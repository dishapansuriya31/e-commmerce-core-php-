CREATE DATABASE ecommerce_db;
USE ecommerce_db;

CREATE TABLE users (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(255),
 email VARCHAR(255) UNIQUE,
 password VARCHAR(255),
 role ENUM('admin','user') DEFAULT 'user',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE products (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(255),
 price DECIMAL(10,2),
 description TEXT,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO products (name, price, description) VALUES
('T-Shirt', 499, 'Cotton T-Shirt'),
('Shoes', 1499, 'Running Shoes'),
('Watch', 999, 'Digital Watch');
