<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    echo "<h2>Purchase Successful!</h2>";
    echo "<a href='products.php'>Back to Products</a>";
}
?>