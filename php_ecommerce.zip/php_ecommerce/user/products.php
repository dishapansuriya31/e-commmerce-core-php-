<?php
session_start();
require '../config/db.php';

if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

if (isset($_GET['add'])) {
    $id = (int)$_GET['add'];
    $_SESSION['cart'][$id] = ($_SESSION['cart'][$id] ?? 0) + 1;
    header("Location: products.php");
    exit;
}

$stmt = $conn->query("SELECT * FROM products ORDER BY id DESC");
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<body>
<h1>Products</h1>
<p>Cart Items: <?php echo array_sum($_SESSION['cart']); ?></p>

<?php foreach($products as $product): ?>
<div style="border:1px solid #ccc; padding:15px; margin:10px;">
    <h3><?php echo $product['name']; ?></h3>
    <p>Price: ₹<?php echo $product['price']; ?></p>
    <p>SKU: SKU-<?php echo $product['id']; ?></p>

    <a href="?add=<?php echo $product['id']; ?>">
        <button>Add To Cart</button>
    </a>

    <a href="checkout.php?product_id=<?php echo $product['id']; ?>">
        <button>Purchase Now</button>
    </a>
</div>
<?php endforeach; ?>
</body>
</html>