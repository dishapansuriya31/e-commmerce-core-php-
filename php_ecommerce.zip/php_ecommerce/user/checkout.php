<?php
require '../config/db.php';
$productId = (int)($_GET['product_id'] ?? 0);

$stmt = $conn->prepare("SELECT * FROM products WHERE id=?");
$stmt->execute([$productId]);
$product = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$product) die("Product not found");
?>
<!DOCTYPE html>
<html>
<body>
<h2>Checkout Page</h2>
<p><strong>Name:</strong> <?php echo $product['name']; ?></p>
<p><strong>Price:</strong> ₹<?php echo $product['price']; ?></p>
<p><strong>SKU:</strong> SKU-<?php echo $product['id']; ?></p>

<form method="POST" action="purchase.php">
    <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
    <button type="submit">Confirm Purchase</button>
</form>
</body>
</html>